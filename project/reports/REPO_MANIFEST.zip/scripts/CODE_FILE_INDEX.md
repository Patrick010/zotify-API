# Code File Index

This file is auto-generated. Do not edit manually.

| Path | Type | Description | Status | Linked Docs | Notes |
|------|------|-------------|--------|-------------|-------|
| `scripts/api/src/zotify_api/temp_violation.py` | | | Active | | |
| `scripts/audit_api.py` | | | Active | | |
| `scripts/audit_endpoints.py` | | | Active | | |
| `scripts/doc-lint-rules.yml` | | | Active | | |
| `scripts/functional_test.py` | | | Active | | |
| `scripts/generate_endpoints_doc.py` | | | Active | | |
| `scripts/generate_openapi.py` | | | Active | | |
| `scripts/lint_governance_links.py` | | | Active | | |
| `scripts/linter.py` | | | Active | | |
| `scripts/make_manifest.py` | | | Active | | |
| `scripts/manage_docs_index.py` | | | Active | | |
| `scripts/repo_inventory_and_governance.py` | | | Active | | |
| `scripts/run_e2e_auth_test.sh` | | | Active | | |
| `scripts/start.sh` | | | Active | | |
| `scripts/test_auth_flow.py` | | | Active | | |
| `scripts/test_single_config.sh` | | | Active | | |
| `scripts/validate_code_index.py` | | | Active | | |
| `scripts/verify_governance.py` | | | Active | | |
