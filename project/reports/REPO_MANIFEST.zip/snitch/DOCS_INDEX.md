# Docs Index

This file is auto-generated. Do not edit manually.

*   [ARCHITECTURE.md](docs/ARCHITECTURE.md)
*   [INSTALLATION.md](docs/INSTALLATION.md)
*   [MILESTONES.md](docs/MILESTONES.md)
*   [MODULES.md](docs/MODULES.md)
*   [PHASES.md](docs/PHASES.md)
*   [PHASE_2_SECURE_CALLBACK.md](docs/PHASE_2_SECURE_CALLBACK.md)
*   [PHASE_2_ZERO_TRUST_DESIGN.md](docs/PHASE_2_ZERO_TRUST_DESIGN.md)
*   [PROJECT_PLAN.md](docs/PROJECT_PLAN.md)
*   [ROADMAP.md](docs/ROADMAP.md)
*   [STATUS.md](docs/STATUS.md)
*   [TASKS.md](docs/TASKS.md)
*   [TEST_RUNBOOK.md](docs/TEST_RUNBOOK.md)
*   [USER_MANUAL.md](docs/USER_MANUAL.md)
*   [phase5-ipc.md](docs/phase5-ipc.md)
*   [CODE_FILE_INDEX.md](./CODE_FILE_INDEX.md)
*   [DOCS_INDEX.md](./DOCS_INDEX.md)
*   [README.md](./README.md)
