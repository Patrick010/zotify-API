# Project Audit Final Report

**Note:** This is a static template. Do **not** overwrite.
Generated content from `PROJECT_DOCUMENT_ALIGNMENT.md` is automatically copied here for human review.

## Summary
- Total files:
- Fully aligned:
- Partially aligned:
- Unlinked:

## Details
<!-- Automatically paste relevant sections from PROJECT_DOCUMENT_ALIGNMENT.md -->