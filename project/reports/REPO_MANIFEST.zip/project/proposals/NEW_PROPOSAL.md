# New Proposal

This is a test proposal to verify the linter functionality.