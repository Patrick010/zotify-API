# Code File Index

This file is auto-generated. Do not edit manually.

| Path | Type | Description | Status | Linked Docs | Notes |
|------|------|-------------|--------|-------------|-------|
| `Gonk/GonkCLI/__init__.py` | | | Active | | |
| `Gonk/GonkCLI/main.py` | | | Active | | |
| `Gonk/GonkCLI/modules/__init__.py` | | | Active | | |
| `Gonk/GonkCLI/modules/jwt_mock.py` | | | Active | | |
| `Gonk/GonkCLI/tests/__init__.py` | | | Active | | |
| `Gonk/GonkCLI/tests/test_jwt_mock.py` | | | Active | | |
| `Gonk/GonkUI/app.py` | | | Active | | |
| `Gonk/GonkUI/static/app.js` | | | Active | | |
| `Gonk/GonkUI/static/styles.css` | | | Active | | |
| `Gonk/GonkUI/templates/index.html` | | | Active | | |
| `Gonk/GonkUI/views/__init__.py` | | | Active | | |
| `Gonk/GonkUI/views/jwt_ui.py` | | | Active | | |
