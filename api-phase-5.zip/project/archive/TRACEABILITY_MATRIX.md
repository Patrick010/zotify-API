⚠️ This file has been migrated into ALIGNMENT_MATRIX.md and is no longer maintained.

# Traceability Matrix – Zotify API

## 1. Roadmap to Execution Plan Traceability

This matrix provides a high-level bridge between the strategic themes outlined in the `ROADMAP.md` and the operational phases in the `EXECUTION_PLAN.md`. Its purpose is to make any drift between the two documents immediately obvious.

| Roadmap Theme | Execution Phases | Deliverables / Notes |
|---|---|---|
| **Phase 1-5: Core Stability & Hardening** | Phases 0-5, 7, 11 | **Aligned.** These roadmap phases correspond to the foundational setup, core API implementation, developer tooling, and initial Spotify integration work in the execution plan. |
| **Phase 6: Platform Extensibility** | Phase 8: Extensibility & Automation | **Aligned.** The roadmap theme maps directly to the corresponding execution phase. |
| **Phase 7: Snitch Module Hardening** | Phase 2 (Snitch Plan) | **Aligned.** The work is detailed in the `snitch/docs/PROJECT_PLAN.md`, which is considered a sub-plan of the main execution plan. |
| **Phase 8: Administrative & Fork-Specific Enhancements** | Phases 6 & 9 | **Aligned.** This roadmap theme groups the operational tasks for admin APIs and fork-specific features. |
| **Phase 9: Release Readiness** | Phase 10: Finalization & Release Readiness | **Aligned.** This roadmap theme maps directly to the final release readiness phase in the execution plan. |
| **Future Vision** | N/A | **Intentional Omission.** The "Future Vision" items are by definition not yet planned for execution and are tracked in `FUTURE_ENHANCEMENTS.md`. |

---

> **Note:** For a high-level summary of feature coverage and gaps, see the [`USECASES_GAP_ANALYSIS.md`](./USECASES_GAP_ANALYSIS.md) document.

## 2. Detailed Requirements Traceability

## Legend
- ✅ Implemented
- 🟡 Partial
- ❌ Missing
- 🔍 Needs Verification

| Requirement ID | Description | Source Doc | Implementation Status | Code Reference | Test Coverage | Linked Enhancement | Notes |
|----------------|-------------|------------|-----------------------|----------------|---------------|--------------------|-------|
| UC-01 | Merge and sync local `.m3u` playlists with Spotify playlists | USECASES.md | ❌ Missing | N/A | N/A | FE-02 | Dependent on Spotify playlist write support |
| UC-02 | Remote playlist rebuild based on metadata filters | USECASES.md | ❌ Missing | N/A | N/A | FE-05 | — |
| UC-03 | Upload local tracks to Spotify library | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-04 | Smart auto-download and sync for playlists | USECASES.md | 🟡 Partial | `services/download_service.py` | 🔍 Needs Verification | FE-03, FE-04 | Lacks automation and file management |
| UC-05 | Collaborative playlist version history | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-06 | Bulk playlist re-tagging for events | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-07 | Multi-format/quality audio library | USECASES.md | 🟡 Partial | `services/download_service.py` | 🔍 Needs Verification | | Lacks multi-format and quality control |
| UC-08 | Fine-grained conversion settings | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-09 | Flexible codec support | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-10 | Automated downmixing for devices | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-11 | Size-constrained batch conversion | USECASES.md | ❌ Missing | N/A | N/A | | |
| UC-12 | Quality upgrade watchdog | USECASES.md | ❌ Missing | N/A | N/A | | |
| **Future Enhancements** | | | | | | | |
| FE-01 | Advanced Admin Endpoint Security | FUTURE_ENHANCEMENTS.md | ❌ Missing | N/A | N/A | | e.g., JWT, rate limiting |
| FE-02 | Persistent & Distributed Job Queue | FUTURE_ENHANCEMENTS.md | 🟡 Partial | `services/download_service.py` | 🔍 Needs Verification | | Currently in-memory DB queue |
| FE-03 | Full Spotify OAuth2 Integration & Library Sync | FUTURE_ENHANCEMENTS.md | 🟡 Partial | `providers/spotify_connector.py` | 🔍 Needs Verification | | Lacks write-sync and full library management. Refactoring to a provider-agnostic auth model is in progress (see SYS-07). |
| FE-04 | Enhanced Download & Job Management | FUTURE_ENHANCEMENTS.md | ❌ Missing | N/A | N/A | | e.g., progress reporting, notifications |
| FE-05 | API Governance | FUTURE_ENHANCEMENTS.md | ❌ Missing | N/A | N/A | | e.g., rate limiting, quotas |
| FE-06 | Observability | FUTURE_ENHANCEMENTS.md | 🟡 Partial | `middleware/request_id.py` | 🔍 Needs Verification | | Lacks detailed audit trails. See FE-07a. |
| FE-07 | Standardized Error Handling | FUTURE_ENHANCEMENTS.md | ✅ Implemented | `core/error_handler/` | ✅ Implemented | | Centralized error handling module is complete and integrated. |
| FE-07a | Flexible Logging Framework (MVP) | FUTURE_ENHANCEMENTS.md | ✅ Implemented | `core/logging_framework/` | ✅ Implemented | FE-06 | Core framework is complete, including configurable sinks (file, console, webhook), tag-based routing, and automatic redaction of sensitive data in production. |
| DOC-01 | Comprehensive Logging Guide | PID.md | ✅ Implemented | `docs/manuals/LOGGING_GUIDE.md` | N/A | FE-07a | A detailed developer guide for the new logging framework has been created as per the project's documentation-first principles. |
| FE-08 | Comprehensive Health Checks | FUTURE_ENHANCEMENTS.md | 🟡 Partial | `routes/system.py` | 🔍 Needs Verification | | Only basic uptime/env endpoints exist |
| FE-09 | Unified Configuration Management | FUTURE_ENHANCEMENTS.md | 🟡 Partial | `services/config_service.py` | 🔍 Needs Verification | | Dual system exists, not unified |
| FE-10 | Dynamic Logging Plugin System | DYNAMIC_PLUGIN_PROPOSAL.md | ❌ Missing | N/A | N/A | FE-07a | A proposal for a dynamic plugin system to allow custom logging sinks. |
| FE-11 | Low-Code Platform Integration | LOW_CODE_PROPOSAL.md | ❌ Missing | N/A | N/A | | A proposal for integrating with platforms like Node-RED. |
| FE-12 | Home Automation Integration | HOME_AUTOMATION_PROPOSAL.md | ❌ Missing | N/A | N/A | | A proposal for integrating with platforms like Home Assistant. |
| FE-13 | Plugin-Driven Metadata System | MULTI_SOURCE_METADATA_PROPOSAL.md | ❌ Missing | N/A | N/A | FE-10 | A proposal for a unified, plugin-driven metadata ingestion and query system. |
| FE-14 | GDPR Data Endpoints | LOW_LEVEL_DESIGN.md | ❌ Missing | N/A | N/A | | Endpoints for data export and deletion. |
| **System Requirements (NFRs)** | | | | | | | |
| SYS-01 | Test Coverage >90% | HIGH_LEVEL_DESIGN.md | ❌ Missing | N/A | `pytest --cov` | | CI gating not implemented |
| SYS-02 | Performance <200ms | HIGH_LEVEL_DESIGN.md | 🔍 Needs Verification | N/A | N/A | | No performance benchmarks exist |
| SYS-03 | Security (Admin Auth) | HIGH_LEVEL_DESIGN.md | ✅ Implemented | `services/auth.py` | 🔍 Needs Verification | FE-01 | Basic API key auth is implemented |
| SYS-04 | Extensibility | HIGH_LEVEL_DESIGN.md | ✅ Implemented | `providers/base.py` | N/A | | Provider model allows for extension |
| SYS-05 | CORS Policy for Web UI | HIGH_LEVEL_DESIGN.md | ✅ Implemented | `zotify_api/main.py` | N/A | | Permissive CORS policy to allow browser-based clients. |
| SYS-06 | Snitch Secure Callback | `snitch/docs/PHASE_2_ZERO_TRUST_DESIGN.md` | 🟡 Partial | `snitch/snitch.go` | ✅ Implemented | | Zero Trust model with end-to-end payload encryption and nonce-based replay protection. |
| SYS-07 | Provider-Agnostic OAuth2 Flow | LLD.md | ✅ Implemented | api/src/zotify_api/providers/ | ✅ Implemented | FE-03 | New requirement to handle OAuth2 callbacks generically in the provider layer. |

---

## 3. Logging System Traceability

| Requirement | Source Doc | Phase(s) | Status |
|-------------|------------|----------|--------|
| Central LoggingService with async pipeline | LOGGING_SYSTEM_DESIGN.md | Phase 1 | ✅ Implemented |
| Developer API with per-module log control | LOGGING_SYSTEM_DESIGN.md | Phase 2 | ✅ Implemented |
| Multi-sink destinations (file, syslog, db, Kafka, RabbitMQ) | LOGGING_SYSTEM_DESIGN.md | Phase 3 | 🟡 Partial |
| Runtime triggers with hot reload | LOGGING_SYSTEM_DESIGN.md | Phase 4 | 🟡 Partial |
| Observability integration (OTel, Prometheus, JSON logs) | LOGGING_SYSTEM_DESIGN.md | Phase 5 | TODO |
| Security & Compliance audit stream | LOGGING_SYSTEM_DESIGN.md | Phase 6 | TODO |
| Extensibility framework for custom adapters | LOGGING_SYSTEM_DESIGN.md | Phase 7 | TODO |
| Full observability suite (dashboard, anomaly detection) | LOGGING_SYSTEM_DESIGN.md | Phase 8 | TODO |
