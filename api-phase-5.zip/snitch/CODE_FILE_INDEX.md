# Code File Index

This file is auto-generated. Do not edit manually.

| Path | Type | Description | Status | Linked Docs | Notes |
|------|------|-------------|--------|-------------|-------|
| `snitch/snitch.go` | | | Active | | |
