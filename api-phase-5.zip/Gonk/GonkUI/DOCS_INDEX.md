# Docs Index

This file is auto-generated. Do not edit manually.

*   [ARCHITECTURE.md](docs/ARCHITECTURE.md)
*   [CHANGELOG.md](docs/CHANGELOG.md)
*   [CONTRIBUTING.md](docs/CONTRIBUTING.md)
*   [USER_MANUAL.md](docs/USER_MANUAL.md)
