# This file is now empty as the schemas have been moved to more appropriate locations
# or removed as they were part of the legacy spotify-specific routes.
