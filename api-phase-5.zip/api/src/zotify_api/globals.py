from datetime import datetime, timezone

app_start_time = datetime.now(timezone.utc)
