import logging


def setup_logging() -> None:
    logging.basicConfig(level=logging.INFO)
