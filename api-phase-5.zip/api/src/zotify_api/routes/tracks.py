from typing import Any, Dict

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile

from zotify_api.providers.base import BaseProvider
from zotify_api.schemas.metadata import (
    MetadataPatchResponse,
    MetadataResponse,
    MetadataUpdate,
)
from zotify_api.schemas.tracks import (
    CreateTrackModel,
    TrackMetadataRequest,
    TrackMetadataResponse,
    TrackResponseModel,
    UpdateTrackModel,
)
from zotify_api.services import tracks_service
from zotify_api.services.auth import require_admin_api_key
from zotify_api.services.db import get_db_engine
from zotify_api.services.deps import get_provider
from zotify_api.services.metadata_service import MetadataService, get_metadata_service

router = APIRouter(prefix="/tracks", tags=["tracks"])


@router.get("", response_model=dict)
def list_tracks(
    limit: int = Query(25, ge=1, le=100),
    offset: int = 0,
    q: str | None = None,
    engine: Any = Depends(get_db_engine),
) -> Dict[str, Any]:
    items, total = tracks_service.get_tracks(
        limit=limit, offset=offset, q=q, engine=engine
    )
    return {"data": items, "meta": {"total": total, "limit": limit, "offset": offset}}


@router.get("/{track_id}", response_model=TrackResponseModel)
def get_track(
    track_id: str, engine: Any = Depends(get_db_engine)
) -> TrackResponseModel:
    track = tracks_service.get_track(track_id, engine)
    if not track:
        raise HTTPException(status_code=404, detail="Track not found")
    return track


@router.post(
    "",
    response_model=TrackResponseModel,
    status_code=201,
    dependencies=[Depends(require_admin_api_key)],
)
def create_track(
    payload: CreateTrackModel, engine: Any = Depends(get_db_engine)
) -> TrackResponseModel:
    try:
        return tracks_service.create_track(payload.model_dump(), engine)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.patch(
    "/{track_id}",
    response_model=TrackResponseModel,
    dependencies=[Depends(require_admin_api_key)],
)
def update_track(
    track_id: str, payload: UpdateTrackModel, engine: Any = Depends(get_db_engine)
) -> TrackResponseModel:
    try:
        return tracks_service.update_track(
            track_id, payload.model_dump(exclude_unset=True), engine
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete(
    "/{track_id}", status_code=204, dependencies=[Depends(require_admin_api_key)]
)
def delete_track(track_id: str, engine: Any = Depends(get_db_engine)) -> None:
    try:
        tracks_service.delete_track(track_id, engine)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{track_id}/cover", dependencies=[Depends(require_admin_api_key)])
async def upload_track_cover(
    track_id: str,
    cover_image: UploadFile = File(...),
    engine: Any = Depends(get_db_engine),
) -> Dict[str, Any]:
    try:
        file_bytes = await cover_image.read()
        result: Dict[str, Any] = tracks_service.upload_cover(
            track_id, file_bytes, engine
        )
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/metadata",
    response_model=TrackMetadataResponse,
    dependencies=[Depends(require_admin_api_key)],
)
async def get_tracks_metadata(
    request: TrackMetadataRequest, provider: BaseProvider = Depends(get_provider)
) -> TrackMetadataResponse:
    """Returns metadata for all given tracks in one call."""
    if not request.track_ids:
        return TrackMetadataResponse(metadata=[])

    metadata = await tracks_service.get_tracks_metadata_from_spotify(
        request.track_ids, provider=provider
    )
    return TrackMetadataResponse(metadata=metadata)


@router.get(
    "/{track_id}/metadata",
    response_model=MetadataResponse,
    summary="Get extended metadata for a track",
)
def get_track_metadata(
    track_id: str, metadata_service: MetadataService = Depends(get_metadata_service)
) -> MetadataResponse:
    """
    Retrieves extended metadata for a specific track.

    - **track_id**: The ID of the track to retrieve metadata for.
    """
    return metadata_service.get_metadata(track_id)


@router.patch(
    "/{track_id}/metadata",
    response_model=MetadataPatchResponse,
    summary="Update extended metadata for a track",
)
def patch_track_metadata(
    track_id: str,
    meta: MetadataUpdate,
    metadata_service: MetadataService = Depends(get_metadata_service),
) -> MetadataPatchResponse:
    """
    Updates extended metadata for a specific track.

    - **track_id**: The ID of the track to update.
    - **meta**: A `MetadataUpdate` object with the fields to update.
    """
    return metadata_service.patch_metadata(track_id, meta)
