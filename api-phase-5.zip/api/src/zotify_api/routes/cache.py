from typing import Any, Dict

from fastapi import APIRouter, Depends

from zotify_api.schemas.cache import CacheClearRequest, CacheStatusResponse
from zotify_api.schemas.generic import StandardResponse
from zotify_api.services.auth import require_admin_api_key
from zotify_api.services.cache_service import CacheService, get_cache_service

router = APIRouter(prefix="/cache", tags=["cache"])


@router.get(
    "",
    response_model=StandardResponse[CacheStatusResponse],
    summary="Get Cache Stats",
    description="Returns statistics about the cache.",
    response_description="Cache statistics.",
)
def get_cache(
    cache_service: CacheService = Depends(get_cache_service),
) -> Dict[str, Any]:
    return {"data": cache_service.get_cache_status()}


@router.delete(
    "",
    summary="Clear Cache",
    description="Clear entire cache or by type.",
    response_description="Cache statistics after clearing.",
    dependencies=[Depends(require_admin_api_key)],
    response_model=StandardResponse[CacheStatusResponse],
)
def clear_cache(
    req: CacheClearRequest, cache_service: CacheService = Depends(get_cache_service)
) -> Dict[str, Any]:
    return {"data": cache_service.clear_cache(req.type)}
